import usb.core
import usb.util
from usb import *
from escposprinter import *
import time
from escposprinter.escpos import EscposIO


class TicketPrinter(object):
    
    def __init__(self, usb_port='001', usb_device='005'):
        device = usb.core.find(idVendor=0x0dd4, idProduct=0x0203)
        # Was it found?
        if device is None:
            raise ValueError('Device not found')
        # Disconnect it from kernel
        needs_reattach = False
        if device.is_kernel_driver_active(0):
            needs_reattach = True
            device.detach_kernel_driver(0)
        # Set the active configuration. With no arguments, the first configuration will be the active one
        device.set_configuration()
        # get an endpoint instance
        cfg = device.get_active_configuration()
        intf = cfg[(0, 0)]
        ep = usb.util.find_descriptor(intf, custom_match=lambda e: usb.util.endpoint_direction(
            e.bEndpointAddress) == usb.util.ENDPOINT_OUT)
        assert ep is not None
        self.dev = device
        self.up = usb_port
        self.ud = usb_device
        

    
    @staticmethod
    def printticket(barcode, timestamp, datestamp, plate):
        with EscposIO(printer.Usb(0x0dd4, 0x0203, 0, 0x81, 0x02)) as p:
            # self.ep.write('\x0A')
            p.writelines('\x1D\xF6')  # align ticket with the print head
            p.writelines('\x1D\x21\x21')  # character size
            p.writelines('\x1B\x61\x31')  # justification centered
            p.writelines('\x1D\x77\x02')  # barcode width
            p.writelines('\x0A')  # print line feed
            p.writelines('\x1D\x6B\x04' + barcode + '\x00')
            p.writelines('\x1B\x7B\x00')  # cancel upside-down printing
            p.writelines('\x1B\x56\x01')  # rotate text 90 degrees for printing arrows
            p.writelines('\xAE \xAE \xAE\x0A')  # print arrows
            p.writelines('\x1B\x56\x00')  # cancel rotate text 90 degrees
            # self.dev.write(0x2, '\x1B\x7B\x00')
            p.writelines('POLISPARK\x0A\x0A')
            p.writelines('\x1D\x21\x11')  # smaller size
            p.writelines('DOUKISSIS\x0A')
            p.writelines('PLAKENTIAS\x0A')
            p.writelines('\x0A\x0A')
            p.writelines('\x1D\x21\x00')  # change character size
            p.writelines('TEL: 210-7255420\x0A')
            p.writelines('DATE: ' + datestamp + '\x0A')
            p.writelines('TIME: ' + timestamp + '\x0A')
            p.writelines('PLATE: ' + plate)
            p.writelines('\x0A')
            p.writelines('\x1D\xF8')  # align ticket @ cut
            p.writelines('\x1B\x69')  # total cut cmd
            p.writelines('\x1C\xC1\x1A')  # paper recovery after cut

    def getticket(self, rid):
        with EscposIO(self.dev) as p:

            p.writelines('\x10\x04\x14')
            time.sleep(0.5)
            while True:
                printerstatus = p.read(0x81, 32)
                print(printerstatus[2:])
                if printerstatus[2] != 0 or printerstatus[3] != 0 or printerstatus[4] != 0 or printerstatus[5] != 0:
                    print('wait to retrieve ticket')
                    p.writelines('\x10\x04\x14')
                    time.sleep(0.5)
                elif printerstatus[2] == 0 and printerstatus[3] == 0 and printerstatus[4] == 0 and printerstatus[5] == 0:
                    print('TICKET WAS RETRIEVED!!!')
                    rid += 1
                    # return True
                    break
            return rid
