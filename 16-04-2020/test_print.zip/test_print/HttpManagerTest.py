import requests
import json
from Logger_setup import logger


class HttpManagerTest:

    def __init__(self):
        with open('TerminalEntranceSettings.json') as json_file:
            self.data = json.load(json_file)

    def sendticketentrance(self, restorationID):
        ticket_entrance = self.data['ticket_entrance']
        api_token = self.data['api_token']
        server_ip = self.data['server_ip']
        request = 'http://' + server_ip + ticket_entrance + restorationID
        ticket_response = requests.get(request, headers={'Authorization': 'Bearer ' + api_token})
        logger.info(ticket_response)
        return ticket_response.status_code, ticket_response.content, ticket_response.headers

    @staticmethod
    def receive_ticket_entrance(result):
        if result == 503:
            logger.info('ticket service unavailable')
        elif result == 200:
            logger.info('ticket entrance granted, 200')
        elif result == 201:
            logger.info('ticket entrance granted, 201')
        elif result == 404:
            logger.info('ticket not found')
        elif result == 500:
            logger.info('server down... send system busy')
        else:
            logger.info("Unknown response status code")
